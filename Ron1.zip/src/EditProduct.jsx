import React from 'react'

export const EditProduct = () => {
    return (
        <div>
            <h1> 1 </h1>
            <h2> 2 </h2>
            <h3> 3 </h3>
        </div>
    )
}
