import React from 'react'
import App from './App'
import { BrowserRouter as Router, Link, Switch, Route } from 'react-router-dom'
import { Login } from './Login'
// import { Products } from './Product'
import { EditProduct } from './EditProduct'

export const AppNav = () => {
    return (
        <Router>
        <div>
            <nav class="navbar navbar-expand-lg navbar-light bg-light">
                <a class="navbar-brand" href="#">Navbar</a>
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarNav">
                    <ul class="navbar-nav">
                        <Route path ="/" component= {AppNav}>
                        <li class="nav-item active">
                            <Link to ="/" class='nav-link'>Home <span class="sr-only">(current)</span></Link>
                        </li>
                        </Route>
                        <Route path= "/Login" component={Login}>
                        <li class="nav-item">
                            <Link class="nav-link" to="/Login">Login</Link>
                        </li>
                        </Route>
                        {/* <Route path="/Products" component={Products}>
                        <li class="nav-item">
                            <Link class="nav-link" to="/Products">Products</Link>
                        </li>
                        </Route> */}
                        <Route path="/EditProd" component={EditProduct}>
                        <li class="nav-item">
                            <Link class="nav-link" to="/EditProd" tabindex="-1" aria-disabled="true">Edit Products</Link></li>
                        </Route>
                    </ul>
                </div>
            </nav>
        </div>
        </Router>
    )
}
