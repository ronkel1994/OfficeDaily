
import React from 'react';
import { useState } from 'react';


export const Login = () => {
    const [user, setuserName] = useState('')
    const [pass, setpass] = useState('')

    // const submithandler = () =>
    // {
    
    //     // user==='abc'? console.log('Username is correct') : console.log('Username is incorrect');
    //     // pass==='123'? console.log('Password is correct') : console.log('Password is incorrect');
    // }
    function callApi() {
        fetch('http://localhost:9000/login', { method: 'GET' })
          .then(data => data.json()) // Parsing the data into a JavaScript object
          .then(json => alert(JSON.stringify(json))) // Displaying the stringified data in an alert popup
      }
      function callApi2()
      {
      fetch('http://localhost:9000/products', {method : 'GET'})
      .then(data=>data.json())
      .then(json => alert(JSON.stringify(json)))
      }
      return (
        <div>
            <form>
                <label>User Name </label>
                <input type = "text" defaultValue ="Enter Login Details" onChange={setuserName}/>
                <h1>{user}</h1>
                <label> Password </label>
                <input type = "password" defaultValue  = "Enter Password" onChange= {setpass}/> 
                <h2>{pass}</h2>
                <button type ="submit" onSubmit = {callApi}>
                    <h2>Login</h2>
                </button>
            </form>
        </div>
    )
}


// function callApi() {
//     fetch('http://localhost:9000/login', { method: 'GET' })
//       .then(data => data.json()) // Parsing the data into a JavaScript object
//       .then(json => alert(JSON.stringify(json))) // Displaying the stringified data in an alert popup


// // import React, { useState } from "react";
// // import App from "./App";
// // import { EditProduct } from "./EditProduct";
// // import { Login } from "./Login";

// export const Products = () => {
//     const [productName, onChangeProductName] = useState('')
//     const [productSpecs, onChangeProductSpecs] = useState('')
//     const [productPrice, onChangeProductPrice] = useState('')

//     const data = () => {
//         setdata = [
//             onChangeProductName == productName,
//             onChangeProductPrice == productPrice,

//         ]
//     };
    

//     return (
//         <div>
//             <label> Product Name : </label>
//             <input type="text" defaultValue="Brand" onChange={onChangeProductName}/>
//             <label>Product Specs : </label>
//             <input type= "text" defaultValue="Description" onChange={onChangeProductSpecs}/>
//             <label> Price: </label>
//             <input type="number" onChange={onChangeProductPrice}/>
//             <button>Delete</button>
//             <button type = "submit" onChange = {data}>Save</button>

//         </div>
//     )
// }
