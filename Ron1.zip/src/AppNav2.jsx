import React from 'react'
// import App from './App'
import { BrowserRouter as Router, Route, Link } from 'react-router-dom'
import { Login } from './Login'
// import { Cart } from '/Cart'
import { Logout } from './Logout'
// import { EditProduct } from './EditProduct'

export const AppNav2 = () => {
    return (
        <Router>
            <ul>
                <Link to ="/"><li>
                    Home
                </li></Link>
                <Link to ="/Product"><li>
                    Product
                </li></Link>
                <Link to = "/EditProduct"><li>
                    Store
                </li></Link>
                <Link to="/Login"><li>
                    Login
                </li></Link>
                <Link to="/Logout"><li>
                    Logout
                </li></Link>
            </ul>
            <Route path = "/" component = {AppNav2}></Route>
                <Route path = "/Login" component = {Login}></Route>
                <Route path = "/Logout" component ={Logout}></Route>
        </Router>
                        
    )
}

export default AppNav2;

function callApi() {
    fetch('http://localhost:3001/fake', { method: 'GET' })
      .then(data => data.json()) // Parsing the data into a JavaScript object
      .then(json => alert(JSON.stringify(json))) // Displaying the stringified data in an alert popup
  }